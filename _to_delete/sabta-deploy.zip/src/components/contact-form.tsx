"use client"

import { useState } from "react"
import { Send } from "lucide-react"
import { categories, contactInfo } from "@/lib/site-data"

export function ContactForm({ initialCategory = "" }: { initialCategory?: string }) {
  const [name, setName] = useState("")
  const [company, setCompany] = useState("")
  const [phone, setPhone] = useState("")
  const [category, setCategory] = useState(initialCategory)
  const [message, setMessage] = useState("")
  const [sent, setSent] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    const subject = `Quote Request${category ? ` — ${category}` : ""}`
    const bodyLines = [
      `Name: ${name}`,
      company && `Company: ${company}`,
      phone && `Phone: ${phone}`,
      category && `Product range: ${category}`,
      "",
      message,
    ].filter(Boolean)

    const mailto = `mailto:${contactInfo.primaryEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyLines.join("\n"))}`
    window.location.href = mailto
    setSent(true)
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Full Name *
          </label>
          <input
            id="name"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="h-12 w-full rounded-lg border border-input bg-background px-4 text-sm outline-none transition-all focus:border-accent focus:ring-2 focus:ring-accent/20"
            placeholder="Your name"
          />
        </div>
        <div>
          <label htmlFor="company" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Company
          </label>
          <input
            id="company"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            className="h-12 w-full rounded-lg border border-input bg-background px-4 text-sm outline-none transition-all focus:border-accent focus:ring-2 focus:ring-accent/20"
            placeholder="Company name"
          />
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="phone" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Phone
          </label>
          <input
            id="phone"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="h-12 w-full rounded-lg border border-input bg-background px-4 text-sm outline-none transition-all focus:border-accent focus:ring-2 focus:ring-accent/20"
            placeholder="+971 ..."
          />
        </div>
        <div>
          <label htmlFor="category" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
            Product Range
          </label>
          <select
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="h-12 w-full rounded-lg border border-input bg-background px-4 text-sm outline-none transition-all focus:border-accent focus:ring-2 focus:ring-accent/20"
          >
            <option value="">Select a range (optional)</option>
            {categories.map((cat) => (
              <option key={cat.slug} value={cat.name}>
                {cat.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label htmlFor="message" className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-muted-foreground">
          What do you need? *
        </label>
        <textarea
          id="message"
          required
          rows={5}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="w-full rounded-lg border border-input bg-background px-4 py-3 text-sm outline-none transition-all focus:border-accent focus:ring-2 focus:ring-accent/20"
          placeholder="Product, grade, standard and quantity you need a quote for"
        />
      </div>

      <button
        type="submit"
        className="inline-flex h-13 w-full items-center justify-center gap-2 rounded-lg btn-primary text-sm sm:w-auto sm:px-10"
      >
        <Send className="size-4 shrink-0" aria-hidden="true" />
        Send Enquiry
      </button>

      {sent && (
        <p className="text-sm font-medium text-accent">
          Opening your email app with this enquiry pre-filled — if it doesn&rsquo;t open, email us directly at{" "}
          <a href={`mailto:${contactInfo.primaryEmail}`} className="underline">
            {contactInfo.primaryEmail}
          </a>
          .
        </p>
      )}
    </form>
  )
}
