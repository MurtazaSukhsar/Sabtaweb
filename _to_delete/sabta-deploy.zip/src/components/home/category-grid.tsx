"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { categories } from "@/lib/site-data"
import { CategoryIcon } from "@/components/category-icon"
import { ScrollReveal } from "@/components/scroll-reveal"

export function CategoryGrid() {
  const [hovered, setHovered] = useState<number | null>(null)

  return (
    <section className="section-pad mx-auto max-w-7xl px-4 sm:px-6 md:px-8 lg:px-12">
      <ScrollReveal>
        <div className="mb-14 flex flex-col items-start gap-3">
          <p className="eyebrow">Product Ranges</p>
          <h2 className="section-heading">Nine Ranges, One Supplier</h2>
          <p className="section-subheading">
            From hose clips to workshop consumables — every range below is stocked and shipping from Dubai.
          </p>
        </div>
      </ScrollReveal>

      <div className="grid gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
        {categories.map((cat, i) => {
          const dimmed = hovered !== null && hovered !== i
          return (
            <ScrollReveal key={cat.slug} delay={i * 50} className={`h-full transition-all duration-300 ${dimmed ? "opacity-60" : ""}`}>
              <Link
                href={`/categories/${cat.slug}`}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                className="card-premium group flex h-full flex-col gap-4 p-6 sm:p-7"
              >
                <div
                  className="flex size-13 items-center justify-center rounded-2xl text-white shadow-md transition-transform duration-300 group-hover:-translate-y-1 group-hover:scale-105"
                  style={{ backgroundColor: cat.color }}
                >
                  <CategoryIcon icon={cat.icon} className="size-6" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-black uppercase leading-tight tracking-tight text-foreground">{cat.name}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{cat.shortDescription}</p>
                </div>
                <div className="flex items-center justify-between border-t border-border pt-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{cat.items.length}+ Product Types</span>
                  <ArrowRight className="size-5 text-accent transition-transform duration-300 group-hover:translate-x-1.5" aria-hidden="true" />
                </div>
              </Link>
            </ScrollReveal>
          )
        })}
      </div>
    </section>
  )
}
