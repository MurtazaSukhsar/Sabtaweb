// Central content store for the Sabta Trading Co. LLC website.
// Every fact here (company profile, contacts, catalogue items, coordinates)
// is sourced directly from SABTA TRADING CATALOG_2026_NEW.pdf — nothing
// invented. Grades quoted (GI, 304, 316, 8.8, 10.9, 12.9, G70, G80, DIN/NFE
// standard numbers) are copied verbatim from the catalogue pages.

export const siteConfig = {
  name: "Sabta Trading Co. LLC",
  nameAr: "شركة سبته التجارية ذ.م.م",
  shortName: "Sabta Trading",
  tagline: "Fasteners & Industrial Hardware Since 1994",
  founded: 1994,
  description:
    "Dubai-based fastener distributor since 1994, stocking 16,000+ items for the Automotive, Manufacturing, Marine and Oilfield industries.",
  url: "https://www.sabtadxb.com",
  itemsInStock: "16,000+",
}

export const contactInfo = {
  phone: "+971 4 2210506",
  phoneHref: "tel:+97142210506",
  fax: "+971 4 2243009",
  poBox: "P.O. Box 14684, Dubai, U.A.E.",
  city: "Dubai, United Arab Emirates",
  website: "www.sabtadxb.com",
  managingDirector: { name: "Saifuddin", role: "Managing Director" },
  contacts: [
    {
      name: "Ali Asgar",
      phone: "+971 50 5649976",
      phoneHref: "tel:+971505649976",
      whatsappHref: "https://wa.me/971505649976",
      email: "ali@sabtadxb.com",
    },
    {
      name: "Husain",
      phone: "+971 50 5092067",
      phoneHref: "tel:+971505092067",
      whatsappHref: "https://wa.me/971505092067",
      email: "husain@sabtadxb.com",
    },
  ],
  // Primary WhatsApp / quote contact used across the site's floating button
  // and forms.
  primaryWhatsappHref: "https://wa.me/971505649976",
  primaryEmail: "ali@sabtadxb.com",
  // Decoded directly from the QR code printed on the back cover of the 2026
  // catalogue (Google "place" link for SABTA TRADING CO LLC).
  mapsPlaceUrl:
    "https://www.google.com/maps/place/SABTA+TRADING+CO+LLC/@25.2697884,55.3054345,17z/data=!3m1!4b1!4m6!3m5!1s0x3e5f43485ed1f901:0x5ff9a43521b4ec62!8m2!3d25.2697884!4d55.3054345!16s%2Fg%2F11bbwpk8pj",
  mapsEmbedSrc: "https://www.google.com/maps?q=25.2697884,55.3054345&z=16&output=embed",
  lat: 25.2697884,
  lng: 55.3054345,
}

export const industries = [
  {
    name: "Automotive",
    description: "Fasteners and clamping hardware supplied to automotive workshops and assembly lines across the UAE.",
  },
  {
    name: "Manufacturing",
    description: "General industrial fasteners, fixings and hardware for manufacturing and production facilities.",
  },
  {
    name: "Marine",
    description: "Corrosion-resistant 316-grade rigging, shackles and lifting hardware built for salt-water and off-shore use.",
  },
  {
    name: "Oilfield",
    description: "High-grade bolting, stud bolts and rigging hardware specified for oilfield and heavy-industrial sites.",
  },
] as const

export type CatalogItem = {
  name: string
  grade?: string
  standard?: string
}

export type Category = {
  slug: string
  name: string
  shortDescription: string
  description: string
  icon: "clamp" | "band" | "rigging" | "marine" | "pin" | "bolt" | "nut" | "washer" | "misc"
  color: string
  brandNote?: string
  pageRange: [number, number]
  items: CatalogItem[]
}

export const categories: Category[] = [
  {
    slug: "hose-clips-clamps",
    name: "Hose Clips & Clamps",
    shortDescription: "Rubit-brand hose clips, P clips, ear clamps and grating clamps.",
    description:
      "Zinc-plated, 304 and marine-grade 316 stainless hose clips and clamps sized 3/8″–12″ (9.5mm–318mm), for general purpose, industrial and off-shore, salt-water applications.",
    icon: "clamp",
    color: "#0f9b3f",
    brandNote: "Rubit Brand",
    pageRange: [3, 9],
    items: [
      { name: "Hose Clip", grade: "Zinc-Plated, 304, 316", standard: "3/8″–12″ & 9.5mm–318mm" },
      { name: "Stainless Steel Rubber Hanging Clamp", grade: "304 & 316" },
      { name: "Stainless Steel P Clip", grade: "304 & 316" },
      { name: "Single Bolt Clamp", grade: "GI, 304 & 316" },
      { name: "Double Wire Clamp", grade: "GI" },
      { name: "Double Ear Clamp", grade: "GI" },
      { name: "Single Ear Clamp", grade: "304" },
      { name: "Muffler Clamp", grade: "GI, 304 & 316" },
      { name: "Beam Clamp", grade: "304" },
      { name: "HDG Grating Clamp", grade: "304 & 316" },
      { name: "SS Grating Clamp", grade: "304 & 316" },
      { name: "Toggle", grade: "GI, 304" },
      { name: "Saddle Clamp", grade: "GI, 304" },
    ],
  },
  {
    slug: "banding-systems",
    name: "Banding & Buckle Systems",
    shortDescription: "Stainless banding strip, buckles and multi-band tools.",
    description:
      "Stainless steel banding strip, ear-lokt buckles and Rubit-brand multi-band systems used to secure hose, cable and pipe bundles.",
    icon: "band",
    color: "#1b8f5a",
    brandNote: "Rubit Brand",
    pageRange: [10, 12],
    items: [
      { name: "Banding Strip", grade: "304 & 316" },
      { name: "Banding Strip Clips", grade: "304 & 316" },
      { name: "Ear Lokt Buckles", grade: "304 & 316" },
      { name: "Multi-Band", grade: "304" },
      { name: "Multi-Band Screw", grade: "304" },
    ],
  },
  {
    slug: "rigging-hardware",
    name: "Rigging Hardware",
    shortDescription: "Shackles, hooks, pulleys, turnbuckles, pad eyes and wire rope.",
    description:
      "A full rigging range — snap hooks, shackles, pulleys, turnbuckles, pad eyes, wire rope and chain — in GI, 304 and marine-grade 316 stainless for lifting and securing loads.",
    icon: "rigging",
    color: "#1b2a80",
    pageRange: [13, 22],
    items: [
      { name: "Snap Hook", grade: "GI, 304, 316" },
      { name: "Snap Hook with Eye", grade: "304, 316" },
      { name: "Snap Hook with Lock", grade: "304, 316" },
      { name: "Snap Hook with Eye Lock", grade: "304, 316" },
      { name: "Swivel Eye Snap Hook", grade: "304, 316" },
      { name: "Swivel Eye Snap Bolt", grade: "304, 316" },
      { name: "Pelican Hook", grade: "304, 316" },
      { name: "Quick Link", grade: "GI, 304, 316" },
      { name: "Pulley Swivel — Single & Double Wheel", grade: "Nickel, 304, 316" },
      { name: "Pulley Fixed — Single & Double Wheel", grade: "Nickel" },
      { name: "D Shackle & Long D Shackle", grade: "GI, 304, 316" },
      { name: "Bow Shackle", grade: "304, 316" },
      { name: "Wire Rope Clip", grade: "GI, 304, 316" },
      { name: "Lifting Eye Bolt & Eye Nut", grade: "GI, 304, 316" },
      { name: "Thimble & Cleat", grade: "GI, 304, 316 / 304, 316" },
      { name: "O Ring", grade: "GI, 304, 316" },
      { name: "Swivel Jaw & Eye / Jaw & Jaw / Eye & Eye", grade: "304, 316" },
      { name: "Eye Bolt & Eye Hook Bolt", grade: "304, 316" },
      { name: "Dog Bolt & Toggle Nut (Butterfly Nut)", grade: "304, 316" },
      { name: "U Bolt with Bracket & Ring Eye Bolt", grade: "304, 316" },
      { name: "Round Eye Plate & Oblong Pad Eye", grade: "304, 316" },
      { name: "Diamond Pad Eye & Square Eye Plate", grade: "304, 316" },
      { name: "Pad Eye Strap & Square Plate with Ring", grade: "304, 316" },
      { name: "Turnbuckle — Hook-to-Eye, Jaw-to-Jaw, Eye-to-Eye, Hook-to-Hook, Pipe Jaw-to-Jaw", grade: "GI, 304, 316" },
      { name: "D Ring", grade: "304, 316" },
      { name: "SS Cargo Hook — Swivel & Fixed", grade: "304, 316" },
      { name: "Delta Quick Link & Bow Nut", grade: "304, 316" },
      { name: "Bow Shackle & D Shackle — Bolt Type", grade: "304, 316" },
      { name: "SS Clevis Grab Hook", grade: "304, 316" },
      { name: "Ferrule", grade: "Aluminum, 304" },
      { name: "Wire Rope Hang Hook — Round & Cross", grade: "304" },
      { name: "Wire Rope Clip — Simplex, Duplex, 8-Type", grade: "304, 316" },
      { name: "Binding Wire & Wire Mesh", grade: "GI" },
      { name: "Link Chain & GI Chain (30m Bag)", grade: "GI, 304, 316" },
      { name: "PVC Wire Rope & Wire Rope", grade: "GI, 304, 316" },
    ],
  },
  {
    slug: "lifting-marine-hardware",
    name: "Lifting & Marine Hardware",
    shortDescription: "G70/G80 chain hardware, hot-dip galvanized shackles and load binders.",
    description:
      "Hot-dip galvanized shackles and wire rope clips together with G70/G80 alloy chain fittings — clevis hooks, connecting links, master links and load binders — rated for lifting and marine service.",
    icon: "marine",
    color: "#0b6dab",
    pageRange: [23, 26],
    items: [
      { name: "Bow Shackle — Screw Pin & Bolt Type", grade: "Hot-Dip Galvanized" },
      { name: "D Shackle — Bolt Type & Screw Pin", grade: "Hot-Dip Galvanized" },
      { name: "Wire Rope Clip", grade: "Hot-Dip Galvanized" },
      { name: "Cargo Latch Kit", grade: "GI" },
      { name: "320A Eye Hook & 322A Swivel Hook", grade: "GI, Alloy" },
      { name: "G70 Clevis Grab Hook & G80 Clevis Sling Hook", grade: "GI, Alloy" },
      { name: "G80 Connecting Link & G80 Clevis Self-Locking Hook", grade: "GI, Alloy" },
      { name: "G80 Eye Self-Locking Hook & Shortening Clutch", grade: "GI, Alloy" },
      { name: "Master Link & Rotating Self-Locking Hook", grade: "GI, Alloy" },
      { name: "Load Binder — Ratchet Type & Lever Type", grade: "GI, Alloy" },
      { name: "G80 MS Chain", grade: "G80" },
    ],
  },
  {
    slug: "clips-pins",
    name: "Clips & Pins",
    shortDescription: "Circlips, snap rings, dowel pins and split/cotter pins.",
    description:
      "DIN-standard circlips and snap rings alongside dowel, hitch, quick-release and split/cotter pins for shaft retention and quick-release assembly work.",
    icon: "pin",
    color: "#c98a2e",
    pageRange: [27, 29],
    items: [
      { name: "Circlip External — DIN471", grade: "MS, 304" },
      { name: "Circlip Internal — DIN472", grade: "MS, 304" },
      { name: "Snap Ring External", grade: "MS" },
      { name: "E Clips", grade: "MS, 304" },
      { name: "Spring Tension Pin", grade: "MS, 304" },
      { name: "Spiral Pin", grade: "MS" },
      { name: "Solid Dowel Pin", grade: "Grade 8" },
      { name: "Clevis Pin", grade: "Yellow" },
      { name: "Hitch Pin", grade: "Yellow" },
      { name: "Quick Release Pin", grade: "GI" },
      { name: "Table Lock Pin — Round & Square", grade: "GI" },
      { name: "Table Lock Pin Square with Eye", grade: "GI" },
      { name: "Tube Pin", grade: "GI" },
      { name: "Lynch Pin", grade: "Yellow, 304" },
      { name: "Industrial Safety Pin", grade: "GI, 304" },
      { name: "R Pin / Double Ring", grade: "GI, 304" },
      { name: "Split Pin / Cotter Pin", grade: "GI, 304" },
    ],
  },
  {
    slug: "bolts-screws",
    name: "Bolts & Screws",
    shortDescription: "Hex, flange, carriage, socket-cap and stud bolts to DIN standards.",
    description:
      "Hex, flange, carriage and roofing bolts, threaded bar, stud bolts and socket-cap screws manufactured to DIN standards in mechanical grades 8.8 through 12.9 and 304/316 stainless.",
    icon: "bolt",
    color: "#1b2a80",
    pageRange: [30, 32],
    items: [
      { name: "Hex Bolt — DIN931 / DIN933", grade: "8.8, 10.9, 12.9, 304, 316" },
      { name: "Flange Bolt — DIN6921", grade: "8.8, 304" },
      { name: "Wing Bolt — DIN316", grade: "304" },
      { name: "Carriage Bolt", grade: "GI, 304" },
      { name: "Roofing Bolt", grade: "GI, 304" },
      { name: "T Slot Bolt", grade: "8.8, 304" },
      { name: "Threaded Bar — DIN975", grade: "8.8, B7, 304, 316" },
      { name: "Full Threaded Stud Bolt", grade: "8.8, B7, 304, 316" },
      { name: "Engineering Stud Bolt", grade: "8.8, 12.9, 304, 316" },
      { name: "Socket Cap Screw — DIN912", grade: "12.9, 304" },
      { name: "Low Head Socket Cap Screw", grade: "12.9, 304" },
      { name: "Socket Pressure Plug — DIN986", grade: "8.8, B7, 304, 316" },
      { name: "U Bolt", grade: "8.8, 304, 316" },
      { name: "CSK Machine Screw Pin", grade: "8.8, 304, 316" },
      { name: "Pan Head Machine Screw", grade: "304" },
      { name: "Weld Stud & Copper Weld Stud", grade: "8.8, 304, 316" },
    ],
  },
  {
    slug: "nuts",
    name: "Nuts",
    shortDescription: "Hex, lock, flange, rivet and specialty nuts.",
    description:
      "Hex, lock, flange, castle and rivet nuts through to specialty types — K nuts, T-slide nuts, cage nuts and weld nuts — in mechanical and stainless grades.",
    icon: "nut",
    color: "#0f9b3f",
    pageRange: [33, 37],
    items: [
      { name: "Hex Nut — DIN934", grade: "8.8, 304, 316" },
      { name: "Hex Cap Nut — DIN1587", grade: "8.8, 10.9, 2H, 304, 316" },
      { name: "Lock Nut — DIN985", grade: "8.8, 304, 316" },
      { name: "Spring Nut", grade: "GI, 304" },
      { name: "Cage Nut", grade: "GI, 304" },
      { name: "Pal Nut — DIN7967", grade: "8.8, 304, 316" },
      { name: "Flange Nut — DIN6923", grade: "8.8, 304" },
      { name: "Castle Nut", grade: "GI, 304" },
      { name: "Wing Nut — DIN315", grade: "GI, 304, 316" },
      { name: "Teeth Nut — DIN1624", grade: "GI, 304, 316" },
      { name: "Rivet Nut & Reduced Head Rivet Nut", grade: "GI, 304" },
      { name: "Clip Nut & Captive Nut", grade: "GI" },
      { name: "PVC Bolt Cap", grade: "Black, White, Grey" },
      { name: "Conical Lock Nut", grade: "GI" },
      { name: "Full Steel Lock Nut & K Nut", grade: "GI / SS 304" },
      { name: "KM Lock Nut", grade: "SS 304" },
      { name: "T Slide Nut", grade: "GI" },
      { name: "Square Nut & Weld Nut", grade: "SS 304" },
      { name: "Coupling Nut & Thin Nuts", grade: "GI, SS 304" },
    ],
  },
  {
    slug: "washers",
    name: "Washers",
    shortDescription: "Flat, spring, serrated and Nordlock washers.",
    description:
      "Flat, spring and serrated washers to DIN125/DIN127/DIN9021, plus Nordlock (NFE25201) and contact (NFE25511) washers for vibration-resistant joints.",
    icon: "washer",
    color: "#5a6178",
    pageRange: [38, 39],
    items: [
      { name: "Flat Washer — DIN125 / DIN9021", grade: "8.8, 304, 316" },
      { name: "Spring Washer — DIN127", grade: "8.8, 304, 316" },
      { name: "Serrated Washer — DIN6798 J/A", grade: "GI, 304" },
      { name: "Starlock Washer", grade: "HDG, 304" },
      { name: "Contact Washer — NFE25511", grade: "Bronze, 304" },
      { name: "Nordlock Washer — NFE25201", grade: "GI, 304" },
      { name: "Copper / MB Lock Washer", grade: "GI" },
      { name: "Shim Washer", grade: "MS" },
      { name: "Bonded Seal Washer & Knurling Washer", grade: "MS" },
      { name: "Aluminum Disc Washer", grade: "Aluminum" },
      { name: "Wave Washer", grade: "MS" },
    ],
  },
  {
    slug: "misc-hardware",
    name: "Grease Fittings & Workshop Hardware",
    shortDescription: "Grease nipples, threading taps & dies, O-rings and rivets.",
    description:
      "Grease nipples and adaptors, threading taps, dies and rivet tools, O-rings and S.R.C rivets — the workshop consumables that round out a fastener order.",
    icon: "misc",
    color: "#8a4bab",
    pageRange: [40, 44],
    items: [
      { name: "Grease Nipple — Button Head & Long", grade: "GI, 304" },
      { name: "Grease Nipple Cup & Cap", grade: "GI" },
      { name: "Grease Adaptor & Grease Adaptor Button Head", grade: "GI, 304" },
      { name: "Grease Nipple Hose", grade: "GI" },
      { name: "Banjo Bolt", grade: "Brass" },
      { name: "Grease Adaptor Pin Type & Grease Nipple Pin Type", grade: "Nickel" },
      { name: "Threading Taps", standard: "NPT, BSP, UNC, UNF, BSW, BSF, Left Thread, Standard, Fine" },
      { name: "Tap Wrench (Tap Handle)" },
      { name: "Round Die & Round Die Handle", standard: "Standard, Fine Thread" },
      { name: "Hex Die & Hammering Rivet" },
      { name: "O Ring — Closed, Cord & Kit (NBR70)", grade: "NBR70, Viton" },
      { name: "Inch & Metric Workshop Assortment", grade: "Customizable to order" },
      { name: "Spring Toggles & Flat Key (Key Bar)", grade: "GI, 304" },
      { name: "Draw Toggle Latch", grade: "GI, 304" },
      { name: "S.R.C Rivets", grade: "Aluminum, 304, 316" },
      { name: "Thread Insert & Thread Repair Kit" },
      { name: "Rivet Gun HR-730 / HR-750" },
      { name: "S Hook", grade: "GI, 304" },
    ],
  },
]

export function getCategory(slug: string) {
  return categories.find((c) => c.slug === slug)
}

export function catalogPagePath(page: number) {
  return `/catalog/page-${String(page).padStart(2, "0")}.webp`
}

export function categoryPageImages(category: Category) {
  const [start, end] = category.pageRange
  const pages: number[] = []
  for (let p = start; p <= end; p++) pages.push(p)
  return pages.map((p) => ({ page: p, src: catalogPagePath(p) }))
}

export const catalogPdfPath = "/SABTA-Trading-Product-Catalog-2026.pdf"

export const faqs = [
  {
    question: "What does Sabta Trading Co. LLC supply?",
    answer:
      "We are a Dubai-based fastener distributor stocking 16,000+ items — hose clips, clamps, rigging and lifting hardware, clips and pins, bolts, screws, nuts, washers and general workshop hardware — for the Automotive, Manufacturing, Marine and Oilfield industries.",
  },
  {
    question: "Do you carry stainless steel (304 / 316) grades?",
    answer:
      "Yes. Most ranges are stocked in 304 stainless for general corrosion resistance and 316 marine-grade stainless for off-shore and salt-water applications, alongside standard GI and mechanical grades (8.8–12.9).",
  },
  {
    question: "Can you source items that are not in ready stock?",
    answer:
      "Yes — with our dedicated list of suppliers we can source any type of fastener that isn’t currently in ready stock. Send us the specification and quantity you need and we’ll quote it.",
  },
  {
    question: "Where are you located and can I collect an order?",
    answer:
      "We are based in Dubai, U.A.E. Contact our sales team on +971 4 2210506 or WhatsApp to confirm stock and arrange collection or delivery.",
  },
  {
    question: "How do I request a quotation?",
    answer:
      "Use the contact form on this site, WhatsApp us directly, or call +971 4 2210506. Include the product name, grade/standard and quantity and our sales team will respond with pricing and availability.",
  },
  {
    question: "Is a full product catalogue available?",
    answer:
      "Yes — our complete 2026 product catalogue (all 9 ranges, with grades and standards) is available to download as a PDF from the Products page, or we can email it to you directly.",
  },
]
