import { Hero } from "@/components/home/hero"
import { TrustBadges } from "@/components/home/trust-badges"
import { CategoryGrid } from "@/components/home/category-grid"
import { CatalogPreview } from "@/components/home/catalog-preview"
import { StatsCounter } from "@/components/home/stats-counter"
import { WhyChooseUs } from "@/components/home/why-choose-us"
import { Industries } from "@/components/home/industries"
import { CtaBanner } from "@/components/home/cta-banner"

export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustBadges />
      <CategoryGrid />
      <CatalogPreview />
      <StatsCounter />
      <WhyChooseUs />
      <Industries />
      <CtaBanner />
    </>
  )
}
