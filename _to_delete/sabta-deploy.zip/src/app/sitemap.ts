import type { MetadataRoute } from "next"
import { categories, siteConfig } from "@/lib/site-data"

export default function sitemap(): MetadataRoute.Sitemap {
  const base = siteConfig.url
  const staticRoutes = ["", "/about", "/products", "/contact", "/faq"].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
  }))

  const categoryRoutes = categories.map((cat) => ({
    url: `${base}/categories/${cat.slug}`,
    lastModified: new Date(),
  }))

  return [...staticRoutes, ...categoryRoutes]
}
