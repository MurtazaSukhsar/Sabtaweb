import type { Metadata } from "next"
import Link from "next/link"
import { ArrowRight, Download } from "lucide-react"
import { Breadcrumbs } from "@/components/breadcrumbs"
import { CategoryIcon } from "@/components/category-icon"
import { ScrollReveal } from "@/components/scroll-reveal"
import { ProductsBrowser } from "@/components/products-browser"
import { CtaBanner } from "@/components/home/cta-banner"
import { catalogPdfPath, categories, siteConfig } from "@/lib/site-data"

export const metadata: Metadata = {
  title: "Products",
  description: `Browse all ${categories.length} fastener and hardware ranges stocked by ${siteConfig.name} — ${siteConfig.itemsInStock} items in stock, Dubai UAE.`,
}

export default function ProductsPage() {
  return (
    <>
      <section className="bg-primary">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 md:px-8 md:py-24 lg:px-12">
          <p className="eyebrow !text-accent">Product Catalogue</p>
          <h1 className="mt-4 max-w-3xl text-balance text-3xl font-extrabold uppercase tracking-tight text-primary-foreground md:text-5xl lg:text-6xl">
            {siteConfig.itemsInStock} Items, Nine Ranges
          </h1>
          <p className="mt-5 max-w-xl text-pretty text-sm leading-relaxed text-primary-foreground/70 md:text-base">
            Every range below is stocked ready to ship from Dubai. Search for a specific product type, browse a range, or
            download the full 2026 catalogue.
          </p>
          <a
            href={catalogPdfPath}
            download="Sabta-Trading-Product-Catalog-2026.pdf"
            className="mt-7 inline-flex h-13 items-center gap-2.5 rounded-xl border border-white/30 bg-white/10 px-7 text-sm font-bold uppercase tracking-wider text-white backdrop-blur-md transition-all hover:bg-white hover:text-primary"
          >
            <Download className="size-4 shrink-0" aria-hidden="true" />
            Download Full Catalog (PDF)
          </a>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-12 md:px-8 md:py-16 lg:px-12">
        <Breadcrumbs crumbs={[{ label: "Products" }]} />

        <div className="mt-10">
          <ProductsBrowser />
        </div>

        <div className="mt-16 grid gap-5 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
          {categories.map((cat, i) => (
            <ScrollReveal key={cat.slug} delay={i * 50} className="h-full">
              <Link href={`/categories/${cat.slug}`} className="card-premium group flex h-full flex-col gap-4 p-6 sm:p-7">
                <div
                  className="flex size-13 items-center justify-center rounded-2xl text-white shadow-md transition-transform duration-300 group-hover:-translate-y-1 group-hover:scale-105"
                  style={{ backgroundColor: cat.color }}
                >
                  <CategoryIcon icon={cat.icon} className="size-6" />
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-black uppercase leading-tight tracking-tight text-foreground">{cat.name}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{cat.description}</p>
                </div>
                <div className="flex items-center justify-between border-t border-border pt-4">
                  <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{cat.items.length}+ Product Types</span>
                  <ArrowRight className="size-5 text-accent transition-transform duration-300 group-hover:translate-x-1.5" aria-hidden="true" />
                </div>
              </Link>
            </ScrollReveal>
          ))}
        </div>
      </div>

      <CtaBanner />
    </>
  )
}
