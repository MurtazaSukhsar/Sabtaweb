import type { Metadata } from "next"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowRight, FileText } from "lucide-react"
import { Breadcrumbs } from "@/components/breadcrumbs"
import { CategoryIcon } from "@/components/category-icon"
import { CatalogGallery } from "@/components/catalog-gallery"
import { ScrollReveal } from "@/components/scroll-reveal"
import { CtaBanner } from "@/components/home/cta-banner"
import { categories, categoryPageImages, getCategory, siteConfig } from "@/lib/site-data"

export function generateStaticParams() {
  return categories.map((cat) => ({ slug: cat.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const category = getCategory(slug)
  if (!category) return {}
  return {
    title: category.name,
    description: `${category.description} Stocked by ${siteConfig.name}, Dubai UAE.`,
  }
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const category = getCategory(slug)
  if (!category) notFound()

  const images = categoryPageImages(category)
  const others = categories.filter((c) => c.slug !== category.slug)

  return (
    <>
      <section className="relative overflow-hidden bg-primary">
        <div className="absolute inset-0 surface-grid opacity-[0.05]" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-18 md:px-8 md:py-20 lg:px-12">
          <div className="flex items-center gap-4">
            <div className="flex size-14 shrink-0 items-center justify-center rounded-2xl text-white shadow-lg" style={{ backgroundColor: category.color }}>
              <CategoryIcon icon={category.icon} className="size-7" />
            </div>
            <div>
              {category.brandNote && <p className="eyebrow !text-accent">{category.brandNote}</p>}
              <h1 className="text-balance text-2xl font-extrabold uppercase tracking-tight text-primary-foreground sm:text-3xl md:text-5xl">
                {category.name}
              </h1>
            </div>
          </div>
          <p className="mt-5 max-w-2xl text-pretty text-sm leading-relaxed text-primary-foreground/75 md:text-base">{category.description}</p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-12 md:px-8 md:py-16 lg:px-12">
        <Breadcrumbs crumbs={[{ label: "Products", href: "/products" }, { label: category.name }]} />

        <div className="mt-10 grid gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
          <ScrollReveal>
            <div>
              <h2 className="text-xl font-extrabold uppercase tracking-tight text-foreground">Product Types In This Range</h2>
              <p className="mt-2 text-sm text-muted-foreground">Grades and standards as stocked — confirm current availability with our sales team.</p>
              <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
                {category.items.map((item) => (
                  <li key={item.name} className="flex flex-col gap-0.5 rounded-lg border border-border bg-card px-4 py-3">
                    <span className="text-sm font-bold text-foreground">{item.name}</span>
                    {(item.grade || item.standard) && (
                      <span className="text-xs text-muted-foreground">
                        {item.grade && <>Grade: {item.grade}</>}
                        {item.grade && item.standard && " · "}
                        {item.standard && <>{item.standard}</>}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={120}>
            <div className="card-premium sticky top-24 flex flex-col gap-5 p-7">
              <h3 className="text-sm font-bold uppercase tracking-wider text-foreground">Request This Range</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Send us the exact size, grade and quantity — our sales team will confirm stock and pricing.
              </p>
              <Link
                href={`/contact?category=${encodeURIComponent(category.name)}`}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-lg btn-primary text-sm"
              >
                Get a Quote
                <ArrowRight className="size-4 shrink-0" aria-hidden="true" />
              </Link>
              <a
                href="/SABTA-Trading-Product-Catalog-2026.pdf"
                download="Sabta-Trading-Product-Catalog-2026.pdf"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-lg btn-secondary text-sm"
              >
                <FileText className="size-4 shrink-0" aria-hidden="true" />
                Download Full Catalog
              </a>
            </div>
          </ScrollReveal>
        </div>

        <div className="mt-16 md:mt-20">
          <h2 className="text-xl font-extrabold uppercase tracking-tight text-foreground">Catalogue Pages</h2>
          <p className="mt-2 mb-6 text-sm text-muted-foreground">Original pages from our 2026 product catalogue — click to enlarge.</p>
          <CatalogGallery images={images} categoryName={category.name} />
        </div>

        <div className="mt-16 border-t border-border pt-12 md:mt-20">
          <h2 className="text-xl font-extrabold uppercase tracking-tight text-foreground">Other Ranges</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {others.slice(0, 4).map((cat) => (
              <Link key={cat.slug} href={`/categories/${cat.slug}`} className="card-premium group flex items-center gap-3 p-4">
                <div className="flex size-10 shrink-0 items-center justify-center rounded-xl text-white" style={{ backgroundColor: cat.color }}>
                  <CategoryIcon icon={cat.icon} className="size-5" />
                </div>
                <span className="text-sm font-bold leading-tight text-foreground">{cat.name}</span>
                <ArrowRight className="ml-auto size-4 shrink-0 text-accent opacity-0 transition-opacity group-hover:opacity-100" aria-hidden="true" />
              </Link>
            ))}
          </div>
        </div>
      </div>

      <CtaBanner />
    </>
  )
}
